package com.example.demo.repository

import com.example.demo.model.Subsystem3Header
import org.springframework.data.jpa.repository.JpaRepository

interface Header3Repository : JpaRepository<Subsystem3Header, String>