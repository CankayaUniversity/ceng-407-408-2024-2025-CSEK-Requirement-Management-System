package com.example.demo.DTO

data class CreateRequirementDTO(
    val title: String,
    val description: String,
    val createdBy: String,
    val flag: Boolean
)
