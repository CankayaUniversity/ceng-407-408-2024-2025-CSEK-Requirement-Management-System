rootProject.name = "eurekaServer"
