package com.example.demo.DTO

data class Subsystem3HeaderDTO(
    val header: String,

    )
