package com.example.demo.dto

data class CreateHeaderDTO(
    val header: String
)