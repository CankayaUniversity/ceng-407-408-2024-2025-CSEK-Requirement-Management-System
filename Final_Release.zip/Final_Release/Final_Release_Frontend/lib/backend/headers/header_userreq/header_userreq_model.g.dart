// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'header_userreq_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Header_UserReq_Model _$Header_UserReq_ModelFromJson(
  Map<String, dynamic> json,
) => Header_UserReq_Model(header: json['header'] as String);

Map<String, dynamic> _$Header_UserReq_ModelToJson(
  Header_UserReq_Model instance,
) => <String, dynamic>{'header': instance.header};
