package com.csek.snapshot.model

class SystemRequirementHeader (
    val header: String
)