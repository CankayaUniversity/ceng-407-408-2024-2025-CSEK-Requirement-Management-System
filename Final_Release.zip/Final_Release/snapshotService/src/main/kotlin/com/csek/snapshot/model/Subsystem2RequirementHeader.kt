package com.csek.snapshot.model

class Subsystem2RequirementHeader (
    val header: String
)