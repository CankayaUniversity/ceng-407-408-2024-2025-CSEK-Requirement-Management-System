package com.csek.snapshot.model

class Subsystem1RequirementHeader (
    val header: String
)