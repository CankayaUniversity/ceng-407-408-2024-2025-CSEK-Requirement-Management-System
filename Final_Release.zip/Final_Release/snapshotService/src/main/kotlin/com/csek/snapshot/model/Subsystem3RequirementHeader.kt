package com.csek.snapshot.model

class Subsystem3RequirementHeader (
    val header: String
)