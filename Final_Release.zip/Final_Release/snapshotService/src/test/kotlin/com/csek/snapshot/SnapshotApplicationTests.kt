package com.csek.snapshot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SnapshotApplicationTests {

	@Test
	fun contextLoads() {
	}

}
