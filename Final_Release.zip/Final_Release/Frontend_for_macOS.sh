#!/bin/bash

SERVICES=("http://localhost:8761/")

while true; do
  all_ready=true

  for url in "${SERVICES[@]}"; do
    if ! curl -s --head --fail "$url" >/dev/null; then
      all_ready=false
    fi
  done

  if [ "$all_ready" = true ]; then
    break
  fi

  sleep 2
done

cd Final_Release_Frontend || exit 1

flutter run -d chrome --web-port=5500 \
  --web-browser-flag="--disable-web-security" \
  --web-browser-flag="--user-data-dir=/tmp/flutter_chrome_user_data"
