package com.project.projectName

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProjectNameApplication

fun main(args: Array<String>) {
	runApplication<ProjectNameApplication>(*args)
}
