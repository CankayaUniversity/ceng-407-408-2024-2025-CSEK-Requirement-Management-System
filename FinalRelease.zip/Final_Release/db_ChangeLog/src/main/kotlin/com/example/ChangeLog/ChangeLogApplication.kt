package com.example.ChangeLog

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ChangeLogApplication

fun main(args: Array<String>) {
	runApplication<ChangeLogApplication>(*args)
}
