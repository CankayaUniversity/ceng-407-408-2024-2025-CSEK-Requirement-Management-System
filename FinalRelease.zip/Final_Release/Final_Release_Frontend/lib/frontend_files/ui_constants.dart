const int uzunluk = 10000;
const double widthUzunluk = 300;
const double isimUzunluk = 80;
