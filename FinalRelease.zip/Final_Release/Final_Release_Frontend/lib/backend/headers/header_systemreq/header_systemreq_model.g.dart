// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'header_systemreq_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Header_SystemReq_Model _$Header_SystemReq_ModelFromJson(
  Map<String, dynamic> json,
) => Header_SystemReq_Model(header: json['header'] as String);

Map<String, dynamic> _$Header_SystemReq_ModelToJson(
  Header_SystemReq_Model instance,
) => <String, dynamic>{'header': instance.header};
