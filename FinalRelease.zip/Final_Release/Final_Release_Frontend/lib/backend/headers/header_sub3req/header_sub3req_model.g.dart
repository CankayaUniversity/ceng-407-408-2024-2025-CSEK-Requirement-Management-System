// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'header_sub3req_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Header_Sub3Req_Model _$Header_Sub3Req_ModelFromJson(
  Map<String, dynamic> json,
) => Header_Sub3Req_Model(header: json['header'] as String);

Map<String, dynamic> _$Header_Sub3Req_ModelToJson(
  Header_Sub3Req_Model instance,
) => <String, dynamic>{'header': instance.header};
