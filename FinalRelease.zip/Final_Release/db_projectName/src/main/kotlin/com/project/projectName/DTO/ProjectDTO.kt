package com.project.projectName.DTO

data class ProjectDTO(
    val name: String
)