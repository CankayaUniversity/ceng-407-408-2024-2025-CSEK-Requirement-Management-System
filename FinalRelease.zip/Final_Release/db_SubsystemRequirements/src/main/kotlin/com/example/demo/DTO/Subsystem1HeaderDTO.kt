package com.example.demo.DTO

data class Subsystem1HeaderDTO(
    val header: String,

)
