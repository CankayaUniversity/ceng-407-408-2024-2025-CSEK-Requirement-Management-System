package com.example.demo.DTO

data class Subsystem2HeaderDTO(
    val header: String,

    )
