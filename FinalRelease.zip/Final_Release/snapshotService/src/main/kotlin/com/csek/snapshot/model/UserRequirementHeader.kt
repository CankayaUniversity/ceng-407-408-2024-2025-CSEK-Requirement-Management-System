package com.csek.snapshot.model

data class UserRequirementHeader (
    val header: String
)